<template>
  <div class="container-md">
    <div
      class="alert alert-success my-4"
      role="alert"
      style="width: 50rem; margin: 0 auto"
    >
      <h4 class="alert-heading">¡Registro exitoso!</h4>
      <p>
        Tu cuenta ha sido registrada correctamente. Para iniciar sesión, ingresa
        al siguiente
        <router-link to="/login" class="alert-link">link</router-link>.
      </p>
      <hr />
      <p class="mb-0">¡Desde ahora disfruta nuestras ofertas y productos!</p>
    </div>
  </div>
</template>
