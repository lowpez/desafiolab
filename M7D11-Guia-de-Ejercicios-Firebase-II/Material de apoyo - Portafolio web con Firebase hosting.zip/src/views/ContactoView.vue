<template>
  <div class="contacto">
    <h1>Página de contacto</h1>
  </div>
</template>