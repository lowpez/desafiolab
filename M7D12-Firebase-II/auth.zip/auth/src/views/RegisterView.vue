<template>
  <RegisterComponent />
</template>

<script>
import RegisterComponent from '@/components/RegisterComponent.vue';

export default {
  components: {
    RegisterComponent,
  },
};
</script>
