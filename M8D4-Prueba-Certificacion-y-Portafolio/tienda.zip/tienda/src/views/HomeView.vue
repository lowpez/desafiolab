<template>
  <div>
    <Carousel />
    <Hero />
  </div>
</template>

<script>
import Carousel from '@/components/Carousel.vue';
import Hero from '@/components/Hero.vue';

export default {
  name: 'HomeView',
  components: { Carousel, Hero },
};
</script>
