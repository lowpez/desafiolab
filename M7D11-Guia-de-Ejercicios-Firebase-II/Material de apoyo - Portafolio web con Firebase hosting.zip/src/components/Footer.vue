<template >
  <div class="bg-secondary">
    <div class="text-white">
      <div class="row">
          <router-link class="nav-link col-3" to="#">Red social 1</router-link> 
          <router-link class="nav-link col-3" to="#">Red social 2</router-link> 
          <router-link class="nav-link col-3" to="#">Red social 2</router-link> 
          <router-link class="nav-link col-3" to="/contacto"> Ir a Contacto</router-link> 
      </div>
    </div>  
  </div>
</template>
<script>
export default {
  
}
</script>
<style >
  
</style>