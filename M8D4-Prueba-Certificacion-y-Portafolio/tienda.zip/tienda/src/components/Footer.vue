<template>
  <div class="text-center p-4 bg-secondary-subtle mt-auto">
    &copy; Tienda 2024
  </div>
</template>
