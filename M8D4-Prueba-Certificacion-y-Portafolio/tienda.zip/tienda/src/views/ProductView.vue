<template>
  <div class="container-md d-flex flex-column min-vh-100">
    <div class="row my-4">
      <div class="col-6">
        <img :src="image" class="img-fluid" />
      </div>
      <div class="col-6">
        <div class="card h-100" style="width: 100%">
          <div class="card-body">
            <h5 class="card-title">{{ title }}</h5>
            <h6 class="card-subtitle my-4 text-body-secondary">
              Categoría: {{ category }}
            </h6>
            <p class="card-text">
              {{ description }}
            </p>
            <p class="fw-bold fs-4">$ {{ price }}</p>
            <button @click="addProduct" class="btn btn-primary">Agregar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapState, mapActions } from 'vuex';
import axios from 'axios';

export default {
  data() {
    return {
      id: '',
      title: '',
      description: '',
      category: '',
      price: '',
      image: '',
    };
  },
  computed: {
    ...mapGetters(['items']),
    ...mapState(['items']),
  },
  mounted() {
    this.getProduct(this.$route.params.id);
  },
  methods: {
    ...mapActions(['addItem']),
    async getProduct(id) {
      try {
        const url = `https://fakestoreapi.com/products/${id}`;
        const resp = await axios.get(url);
        const data = resp.data;
        this.id = data.id;
        this.title = data.title;
        this.description = data.description;
        this.category = data.category;
        this.price = data.price;
        this.image = data.image;
      } catch (error) {
        console.log(error);
      }
    },
    addProduct() {
      this.addItem({
        id: this.id,
        title: this.title,
        description: this.description,
        category: this.category,
        price: this.price,
        image: this.image,
      });
      console.log(this.items);
    },
  },
};
</script>
