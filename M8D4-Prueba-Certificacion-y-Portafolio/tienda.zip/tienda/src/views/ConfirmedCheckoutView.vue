<template>
  <div class="container-md">
    <div
      class="alert alert-success my-4"
      role="alert"
      style="width: 50rem; margin: 0 auto"
    >
      <h4 class="alert-heading">¡Pago exitoso!</h4>
      <p>
        Tu pago fue realizado con éxito. Tu compra está siendo gestionada para
        ser despachada.
      </p>
    </div>
  </div>
</template>
