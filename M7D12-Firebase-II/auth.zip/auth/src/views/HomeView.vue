<template>
  <div>
    <h1 class="mt-4 text-center">Home</h1>
  </div>
</template>

<script>
export default {
  name: 'HomeView',
  components: {},
};
</script>
