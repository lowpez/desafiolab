<template>
  <div id="pokemon">
    <div v-if="ready">
      <img :src="img" :class="{ filtro: !active }" />
    </div>
    <div v-if="!active">
      <div>
        <input v-model="inputPokemon" />
      </div>
      <div>
        <button @click="$emit('validar', inputPokemon, nombrePokemon, id)">
          Descubrir
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'PokemonBase',
  props: ['active', 'url', 'id'],
  data() {
    return {
      inputPokemon: '',
      nombrePokemon: '',
      img: '',
      ready: false,
    };
  },
  methods: {
    obtenerPokemon: async function (url) {
      const { data } = await axios.get(url);
      this.img = data.sprites.front_default;
      this.nombrePokemon = data.name;
      this.ready = true;
    },
  },
  mounted() {
    this.obtenerPokemon(this.url);
  },
};
</script>

<style scoped>
#pokemon {
  flex: 1 0 21%;
  margin: 5px;
  height: 200px;
}

div {
  text-align: center;
}

button {
  margin-top: 10px;
}

.filtro {
  filter: blur(5px) grayscale(100%);
}
</style>
