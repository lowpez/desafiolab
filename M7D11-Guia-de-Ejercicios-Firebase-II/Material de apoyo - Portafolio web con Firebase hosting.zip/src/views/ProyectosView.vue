<template>
  <div class="proyectos">
    <h1>Página de proyectos</h1>
  </div>
</template>