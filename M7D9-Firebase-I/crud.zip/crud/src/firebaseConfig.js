// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyBvGBuv7UUG3Ldrlpxb8IanxwjipNUkUcg',
  authDomain: 'crud-3945a.firebaseapp.com',
  projectId: 'crud-3945a',
  storageBucket: 'crud-3945a.appspot.com',
  messagingSenderId: '916231982059',
  appId: '1:916231982059:web:15941899bae379f34667ae',
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);

export default firebaseApp;
