<template>
  <div>
    <table>
      <tr>
        <td>
          <label
            :class="{
              error: paciente.length == 0,
            }"
            >Paciente</label
          >
          <input v-model="paciente" />
        </td>
        <td>
          <label
            :class="{
              error: fecha.length == 0,
            }"
            >Fecha</label
          >
          <input type="date" v-model="fecha" />
        </td>
        <td>
          <label
            :class="{
              error: hora.length == 0,
            }"
            >Hora</label
          >
          <input type="time" v-model="hora" />
        </td>
        <td>
          <label
            :class="{
              error: gravedad.length == 0,
            }"
            >Gravedad</label
          >
          <select v-model="gravedad">
            <option v-for="(g, i) in gravedades" :key="i">
              {{ g }}
            </option>
          </select>
        </td>
        <td>
          <label
            :class="{
              error: motivo.length == 0,
            }"
            >Motivo</label
          >
          <input v-model="motivo" />
        </td>
      </tr>
      <tr>
        <td colspan="5" class="center">
          <button
            @click="agregar"
            :class="{
              disabled:
                paciente.length == 0 ||
                fecha.length == 0 ||
                hora.length == 0 ||
                gravedad.length == 0 ||
                motivo.length == 0,
            }"
          >
            Agregar
          </button>
        </td>
      </tr>
    </table>
    <div v-if="citas.length > 0">
      <div v-for="(cita, llave) in citas" :key="llave">
        <CitaMedica
          :paciente="cita.paciente"
          :fecha="cita.fecha"
          :hora="cita.hora"
          :motivo="cita.motivo"
          :gravedad="cita.gravedad"
          @eliminarCita="citas.splice(llave, 1)"
        />
      </div>
    </div>
    <div v-else class="center">
      <span class="error">Aún no hay consultas registradas</span>
    </div>
  </div>
</template>

<script>
import CitaMedica from './components/CitaMedica.vue';

export default {
  name: 'App',
  components: {
    CitaMedica,
  },
  data() {
    return {
      paciente: '',
      fecha: '',
      hora: '',
      motivo: '',
      gravedad: '',
      gravedades: ['baja', 'media', 'alta'],
      citas: [
        {
          paciente: 'Brendan Eich',
          fecha: '2023-01-11',
          hora: '08:20',
          motivo: 'Gripe con tos',
          gravedad: 'media',
        },
        {
          paciente: 'Jhon Doe',
          fecha: '2023-02-05',
          hora: '10:20',
          motivo: 'Examen',
          gravedad: 'baja',
        },
      ],
    };
  },
  methods: {
    limpiar: function () {
      this.paciente = '';
      this.fecha = '';
      this.hora = '';
      this.motivo = '';
      this.gravedad = '';
    },
    agregar: function () {
      this.citas.push({
        paciente: this.paciente,
        fecha: this.fecha,
        hora: this.hora,
        motivo: this.motivo,
        gravedad: this.gravedad,
      });
      this.limpiar();
    },
  },
};
</script>

<style>
table,
input,
select {
  width: 100%;
}

tr td {
  padding: 10px;
}

label {
  display: block;
  text-align: center;
}

.center {
  text-align: center;
}

.error {
  font-weight: bold;
  color: red;
}

.disabled {
  border: 1px solid black;
  background-color: grey;
  color: white;
  padding: 15px;
  cursor: not-allowed;
}
</style>
