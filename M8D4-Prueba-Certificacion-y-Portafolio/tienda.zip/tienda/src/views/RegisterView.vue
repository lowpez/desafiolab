<template>
  <div class="container-md my-4 d-flex flex-column min-vh-100">
    <h3 class="text-center">Registro</h3>
    <div class="card my-4" style="width: 18rem; margin: 0 auto">
      <div class="card-body">
        <form>
          <div class="mb-3">
            <label for="exampleInputName" class="form-label">Nombre</label>
            <input
              v-model="name"
              type="text"
              class="form-control"
              id="exampleInputName"
            />
          </div>
          <div class="mb-3">
            <label for="exampleInputPhone" class="form-label">Teléfono</label>
            <input
              v-model="phone"
              type="text"
              class="form-control"
              id="exampleInputPhone"
            />
          </div>
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Correo</label>
            <input
              v-model="email"
              type="email"
              class="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
            />
          </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label"
              >Contraseña</label
            >
            <input
              v-model="password"
              type="password"
              class="form-control"
              id="exampleInputPassword1"
            />
          </div>
          <button @click="register" class="btn btn-primary">Registrar</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      name: '',
      email: '',
      password: '',
      phone: '',
    };
  },
  methods: {
    async register() {
      try {
        const url =
          'https://raw.githubusercontent.com/hleytondiaz/api-test/main/register.json';
        const resp = await axios.get(url);
        const data = resp.data.registerUser;
        const nameData = data.name;
        const phoneData = data.phone;
        const emailData = data.email;
        const passwordData = data.password;
        console.log(nameData);
        console.log(phoneData);
        console.log(emailData);
        console.log(passwordData);
        this.$router.push('/login');
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
