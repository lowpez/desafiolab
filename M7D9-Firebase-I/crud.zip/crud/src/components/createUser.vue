<template>
  <div>
    <h3>Registro de usuario</h3>
    <form @submit.prevent="addUser">
      <input type="text" v-model="name" placeholder="Nombre" />
      <br /><br />
      <input type="text" v-model="lastname" placeholder="Apellido" />
      <br /><br />
      <input type="text" v-model="email" placeholder="Correo" />
      <br /><br />
      <input type="password" v-model="password" placeholder="Contraseña" />
      <br /><br />
      <button type="submit">Agregar usuario</button>
    </form>
    <hr />
  </div>
</template>

<script>
import firebaseApp from '../firebaseConfig';
import { getFirestore, collection, addDoc } from 'firebase/firestore';

export default {
  name: 'CreateUser',
  data() {
    return {
      name: '',
      lastname: '',
      email: '',
      password: '',
    };
  },
  methods: {
    async addUser() {
      if (this.name.trim() === '') return;
      if (this.lastname.trim() === '') return;
      if (this.email.trim() === '') return;
      if (this.password.trim() === '') return;

      const db = getFirestore(firebaseApp);
      const usersRef = collection(db, 'usuarios');

      await addDoc(usersRef, {
        nombre: this.name,
        apellido: this.lastname,
        correo: this.email,
        password: btoa(this.password),
      });

      this.name = '';
      this.lastname = '';
      this.email = '';
      this.password = '';
    },
  },
};
</script>
