<template>
  <div>
    <LoginComponent />
  </div>
</template>

<script>
import LoginComponent from '@/components/LoginComponent.vue';

export default {
  components: {
    LoginComponent,
  },
};
</script>
