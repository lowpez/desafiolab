<template>
  <div class="container-md d-flex flex-column min-vh-100">
    <div class="row my-4">
      <div class="col-12">
        <div class="row">
          <div
            class="col-12 col-sm-6 col-md-3 mb-4"
            v-for="(producto, key) in productos"
            key="key"
          >
            <Item
              :id="producto.id"
              :title="producto.title"
              :price="producto.price"
              :image="producto.image"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Item from '../components/Item.vue';

export default {
  components: {
    Item,
  },
  data() {
    return {
      productos: [],
    };
  },
  mounted() {
    this.fetchProducts();
  },
  methods: {
    async fetchProducts() {
      try {
        const url = 'https://fakestoreapi.com/products';
        const resp = await axios.get(url);
        const data = resp.data;
        this.productos = data;
        console.log(this.productos);
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
