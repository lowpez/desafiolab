<template>
  <div
    :class="{
      verde: gravedad === 'baja',
      amarillo: gravedad === 'media',
      rojo: gravedad === 'alta',
    }"
  >
    <h4>Paciente</h4>
    <p>{{ paciente }}</p>
    <h4>Fecha</h4>
    <p>{{ fecha }}</p>
    <h4>Hora</h4>
    <p>{{ hora }}</p>
    <h4>Motivo</h4>
    <p>{{ motivo }}</p>
    <button @click="$emit('eliminarCita')">Eliminar</button>
  </div>
</template>

<script>
export default {
  name: 'CitaMedica',
  props: ['paciente', 'fecha', 'hora', 'motivo', 'gravedad'],
};
</script>

<style scoped>
div {
  padding: 10px;
  margin-right: 10px;
  width: 150px;
  border: 1px solid;
  text-align: center;
  float: left;
}

.verde {
  background-color: green;
}

.amarillo {
  background-color: yellow;
}

.rojo {
  background-color: red;
}
</style>
