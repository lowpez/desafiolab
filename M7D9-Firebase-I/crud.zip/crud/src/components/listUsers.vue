<template>
  <div>
    <table border="1" width="100%">
      <thead>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Correo</th>
        <th>Acción</th>
      </thead>
      <tbody>
        <tr v-for="usuario in users" :key="usuario.id">
          <td>{{ usuario.nombre }}</td>
          <td>{{ usuario.apellido }}</td>
          <td>{{ usuario.correo }}</td>
          <td>
            <button @click="deleteUser(usuario.id)">Eliminar</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import firebaseApp from '../firebaseConfig';
import {
  getFirestore,
  collection,
  onSnapshot,
  deleteDoc,
  doc,
} from 'firebase/firestore';

export default {
  name: 'ListUsers',
  data() {
    return {
      users: [],
    };
  },
  methods: {
    async deleteUser(userId) {
      const db = getFirestore(firebaseApp);
      const userRef = doc(db, 'usuarios', userId);
      await deleteDoc(userRef);
    },
  },
  mounted() {
    const db = getFirestore(firebaseApp);
    const usersRef = collection(db, 'usuarios');
    onSnapshot(usersRef, (snapshot) => {
      this.users = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
    });
  },
};
</script>
