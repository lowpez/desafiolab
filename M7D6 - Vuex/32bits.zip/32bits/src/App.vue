<template>
  <div>
    <div class="encabezados">
      <h1>Tienda 32Bits</h1>
      <h2>Lista de videojuegos</h2>
      <!--<button @click="getProductos">Obtener productos</button>-->
    </div>
    <div>
      <table>
        <thead>
          <th>Código</th>
          <th>Nombre</th>
          <th>Stock</th>
          <th>Precio</th>
          <th>Acciones</th>
        </thead>
        <tbody>
          <tr v-for="(item, key) in $store.state.productos" :key="key">
            <td>{{ item.codigo }}</td>
            <td>{{ item.nombre }}</td>
            <td>{{ item.stock }}</td>
            <td>$ {{ item.precio }}</td>
            <td>
              <button
                @click="
                  updateProductoAction({ indice: key, operacion: 'restar' })
                "
              >
                -
              </button>
              &nbsp;
              <button
                @click="
                  updateProductoAction({ indice: key, operacion: 'sumar' })
                "
              >
                +
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex';

export default {
  name: 'App',
  components: {},
  methods: {
    ...mapActions(['getProductos', 'updateProductoAction']),
  },
  mounted() {
    this.getProductos();
  },
};
</script>

<style>
.encabezados {
  text-align: center;
}

table {
  text-align: center;
  width: 100%;
}

th,
tr td {
  border: 1px solid;
}
</style>
