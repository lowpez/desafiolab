<template >
  <div>
    <nav class="navbar navbar-expand-lg bg-info">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <router-link class="nav-link" to="/">Home</router-link> |
            <router-link class="nav-link" to="/about">Acerca de mí</router-link> |
            <router-link class="nav-link" to="/proyectos">Mis proyectos</router-link> |
            <router-link class="nav-link" to="/contacto">Contacto</router-link> 
          </div>
        </div>
      </div>
    </nav>
  </div>
</template>
<script>
export default {
  
}
</script>
<style >
  
</style>