<template>
  <div class="container-md">
    <div class="row my-4">
      <div class="col-12">
        <h2>Ofertas</h2>
      </div>
      <div class="col-12">
        <div class="row">
          <div v-for="oferta in ofertas" :key="oferta.id" class="col-4">
            <div class="card" style="width: 100%">
              <img :src="oferta.image" class="card-img-top" />
              <div class="card-body">
                <h5 class="card-title">{{ oferta.title }}</h5>
                <p class="card-text">{{ oferta.description }}</p>
                <a href="#" class="btn btn-primary">$ {{ oferta.price }}</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ofertas: [
        {
          id: 1,
          title: 'Oferta 1',
          description: 'Descripción Oferta 1',
          price: 10000,
          image:
            'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Example_image.svg/600px-Example_image.svg.png',
        },
        {
          id: 2,
          title: 'Oferta 2',
          description: 'Descripción Oferta 2',
          price: 20000,
          image:
            'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Example_image.svg/600px-Example_image.svg.png',
        },
        {
          id: 3,
          title: 'Oferta 3',
          description: 'Descripción Oferta 3',
          price: 30000,
          image:
            'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Example_image.svg/600px-Example_image.svg.png',
        },
      ],
    };
  },
};
</script>
