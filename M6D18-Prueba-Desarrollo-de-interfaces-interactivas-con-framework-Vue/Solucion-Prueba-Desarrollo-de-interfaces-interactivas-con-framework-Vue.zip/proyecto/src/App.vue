<template>
  <div id="app">
    <div class="header">
      <div>
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnpDDd16-m8fTneCbtEI1TYpDiVqegO11beA&s"
        />
      </div>
      <h1>¿Quién es ese Pokémon?</h1>
      <p>
        Pokemones descubiertos:
        <strong>{{ pokemonesDescubiertos }}</strong>
      </p>
    </div>
    <div class="pokemones">
      <div v-for="(item, key) in pokemones" :key="key">
        <PokemonBase
          :id="item.id"
          :active="item.active"
          :url="item.url"
          @validar="validar"
        />
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import PokemonBase from './components/PokemonBase.vue';

export default {
  name: 'App',
  components: { PokemonBase },
  methods: {
    obtenerPokemones: async function () {
      try {
        const url = 'https://pokeapi.co/api/v2/pokemon';
        const { data } = await axios.get(url);
        this.pokemones = data.results;
        for (let i = 0; i < this.pokemones.length; i++) {
          this.pokemones[i].id = i;
          this.pokemones[i].active = false;
        }
      } catch (error) {
        console.log(error);
      }
    },
    validar: function (inputPokemon, nombrePokemon, id) {
      if (inputPokemon === nombrePokemon) {
        this.pokemones[id].active = true;
        this.pokemonesDescubiertos++;
      }
      console.log(nombrePokemon);
    },
  },
  mounted() {
    this.obtenerPokemones();
  },
  data() {
    return {
      pokemones: [],
      pokemonesDescubiertos: 0,
    };
  },
};
</script>

<style>
#app {
  font-family: arial;
}

.header {
  text-align: center;
}

.pokemones {
  display: flex;
  flex-wrap: wrap;
}
</style>
