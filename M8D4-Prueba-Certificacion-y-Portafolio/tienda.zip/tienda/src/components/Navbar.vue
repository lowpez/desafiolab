<template>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-md">
      <router-link to="/" class="navbar-brand">Tienda</router-link>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <router-link to="/" class="nav-link">Inicio</router-link>
          </li>
          <li class="nav-item">
            <router-link to="/products" class="nav-link">Productos</router-link>
          </li>
          <div class="d-flex">
            <li class="nav-item">
              <router-link to="/login" class="nav-link">Login</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/register" class="nav-link"
                >Registro</router-link
              >
            </li>
            <li>
              <router-link to="/cart" type="button" class="btn btn-primary"
                >Carrito
                <span class="badge text-bg-secondary">{{
                  totalItems
                }}</span></router-link
              >
            </li>
          </div>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
import { mapGetters, mapState } from 'vuex';
export default {
  computed: {
    ...mapGetters(['items', 'totalItems']),
    ...mapState(['items']),
  },
};
</script>
