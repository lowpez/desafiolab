<template>
  <div>
    <CreateUser />
    <ListUsers />
  </div>
</template>

<script>
import CreateUser from './components/createUser.vue';
import ListUsers from './components/listUsers.vue';

export default {
  name: 'App',
  components: {
    CreateUser,
    ListUsers,
  },
};
</script>

<style></style>
